<?php

$loader = require '../autoload.php';

$lrs = new TinCan\RemoteLRS(
    'https://deepak.waxlrs.com/TCAPI',
    '1.0.0',
    'XotfkeY9diTGGTc9K2Qs',
    'tq8IW3phPSzwToeE7xDb'
);
$response = $lrs->queryStatements(['limit' => 200]);
$res = json_decode($response);


$i=0;
$arr = array();
foreach($res->statements as $v)
{
	$a= (array)$v->verb->display;
	if($a['en-US'] == 'experienced'){
		//$arr[$i]['verb'] = $a['en-US'];
		$a= (array)$v->object->definition->name;
		$arr[] = $a['en-US'];
		//$a= (array)$v->object->definition->description;
		//$arr[$i]['description'] = $a['en-US'];
	}
	$i++;
}


$finalArr = array_count_values($arr);

?>

	


  
  
  
  <!doctype html>
<html>
<head>
  <script src="//cdn.anychart.com/js/7.9.0/anychart-bundle.min.js"></script>
  <style>
    html, body, #container {
      width: 100%;
      height: 100%;
      margin: 0;
      padding: 0;
    }
  </style>
</head>
<body>
    <div id="container"></div>
    <script type="text/javascript">
anychart.onDocumentReady(function() {
  // create bar chart
  chart = anychart.bar();

  // turn on chart animation
  chart.animation(true);

  // set container id for the chart
  chart.container('container');
  chart.padding([10,40,5,20]);

  // set chart title text settings
  chart.title('Page Statistics');

  // create area series with passed data
  var series = chart.bar([
<?
				 foreach($finalArr as $key=>$value){
							
					echo "['".$key."',".$value."],";
					
				 } ?>
  ]);
  // set tooltip formatter
  series.tooltip().titleFormatter(function(){return this.x});
  series.tooltip().textFormatter(function () {
      return ' ' + parseInt(this.value).toLocaleString();
  });
  series.tooltip().position('right').anchor('left').offsetX(5).offsetY(0);

  // set yAxis labels formatter
  chart.yAxis().labels().textFormatter(function(){
      return this.value.toLocaleString();
    });

  // set titles for axises
  chart.xAxis().title('Page Title');
  chart.yAxis().title('Number of Views By All Students');
  chart.interactivity().hoverMode('byX');
  chart.tooltip().positionMode('point');
  // set scale minimum
  chart.yScale().minimum(0);

  // initiate chart drawing
  chart.draw();
});

    </script>
</body>
</html>