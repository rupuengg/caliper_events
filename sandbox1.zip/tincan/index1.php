<?php
$loader = require '../autoload.php';

$lrs = new TinCan\RemoteLRS(
    'https://rakesh.waxlrs.com/TCAPI',
    '1.0.0',
    'MQdTRzVexH7OVCTHdYX5',
    '1qXmE5Z0ASOOjVZXnOA2'
);
$response = $lrs->queryStatements(['limit' => 200]);
$res = json_decode($response);


$i=0;
$arr = array();
foreach($res->statements as $v)
{
	$a= (array)$v->verb->display;
	if($a['en-US'] == 'experienced'){
		//$arr[$i]['verb'] = $a['en-US'];
		$a= (array)$v->object->definition->name;
		$arr[] = $a['en-US'];
		//$a= (array)$v->object->definition->description;
		//$arr[$i]['description'] = $a['en-US'];
	}
	$i++;
}


$finalArr = array_count_values($arr);
$res = array();
foreach($finalArr as $key=>$value)
{
    $res[] = array('name'=> $key,'y'=>$value);
} 
$jsonChart = json_encode($res);
?>

	


  
  
  
  <!doctype html>
<html>
<head>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.min.js"></script>
  <script src="https://code.highcharts.com/highcharts.js"></script>
  <script src="https://code.highcharts.com/modules/data.js"></script>
  <style>
    html, body{
      width: 100%;
      height: 100%;
      margin: 0;
      padding: 0;
    }
    #container {
        width: 80% !important;
    }
  </style>
</head>
<body>
    <div id="container" style="min-width: 110px; height: 250px;"></div>
    <div id="statement">
        <script type="text/javascript" id="waxid-f725110a-8e43-417a-92c7-bdd175d0e7d4">
var _waxr = _waxr || [];

(function () {
    var reportembed = document.createElement('script'); reportembed.defer = true; reportembed.type = 'text/javascript';
    reportembed.src = 'https://rakesh.waxlrs.com/embed.js';
    _waxr.push(['report', 'activitystream', '8GyI4FbInfKSca6Rte36b/LOAZ+IPEsnMQ0dlmcd0t8ItIKHqoRk5wFN7+lstwk7d85fQuylW42zgs/QEKG0hmOr8fVmKDLJe17DWd5hsTrvoAZLgf05x4GgV+eMNHBt2WKmkCo8U0hZpWtnWBpa1MNcbZ3QwJIfJzjY9aTXU5IOF+oHC53tgE1HzbjoOteG5xP0ACCv8LJ+oyFQ2GJxqSElLnTzS213VLsog2MCwanRXjYbajL5Zh7X+nQkXARJx8K6uu258nhehBMav+Jm8fxBMCBnFd9MU2QGKH8ZY8Cv+hd2Fkf/O+juaBhVT5Pw3m4GXYSRYXlrRUJI3wAMEe4AB/3xaZtoMM/1wwA+SOTTaOP7SI2RZ2YVniRsIn6EajIFAboZeCdTklvzi+iYG0pI+sU1e1+hn4hxtoRatMATScofCrveCBcvlAXPbFLLse2AUQJ8gDNZ/mfAWzNfnPAb+rEVWvp61mHvN+BzArW94GTb+4fmNQ0ui+vBHPepJTSZaDDLm+Pltq5jY4hDj87jbuSFDGY89Xgghi4uH3C794eAxMGGAynt2JxSrd92cIRv9xaEBg==', reportembed]);
    var s = document.getElementById('waxid-f725110a-8e43-417a-92c7-bdd175d0e7d4');
    s.parentNode.insertBefore(reportembed, s);
})();
</script>
    </div>
    <script type="text/javascript">
     $(function () {
    // Create the chart
    $('#container').highcharts({
        chart: {
            type: 'column'
        },
        title: {
            text: 'Page Statistics'
        },
        xAxis: {
            type: 'category'
        },
        yAxis: {
            title: {
                text: 'Total Views'
            }

        },
        legend: {
            enabled: false
        },
        plotOptions: {
            series: {
                borderWidth: 0,
                dataLabels: {
                    enabled: false,
                    format: '{point.y:.1f}%'
                }
            }
        },

        tooltip: {
            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2}</b><br/>'
        },

        series: [{
            name: 'Title',
            colorByPoint: true,
            data: <?php echo $jsonChart;?>,
        }],
        
    });
});
    </script>
</body>
</html>